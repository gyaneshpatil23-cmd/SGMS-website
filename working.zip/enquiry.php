<?php

//Retrieve form data.
//GET - user submitted data using AJAX
//POST - in case user does not support javascript, we'll use POST instead
function formvalue($key) {
	$value = isset($_GET[$key]) && $_GET[$key] !== '' ? $_GET[$key] : (isset($_POST[$key]) ? $_POST[$key] : '');
	return is_string($value) ? trim($value) : '';
}
$name = formvalue('name');
$phone = formvalue('phone');
$organisation = formvalue('organisation');
$service = formvalue('service');
$comment = formvalue('message');

//flag to indicate which method it uses. If POST set it to 1
$post = $_POST ? 1 : 0;

//Simple server side validation
$errors = array();
if (!$name) $errors[count($errors)] = 'Please enter your name.';
if (!$phone) $errors[count($errors)] = 'Please enter your phone number.';
if (!$service) $errors[count($errors)] = 'Please select a service.';
if (!$comment) $errors[count($errors)] = 'Please enter your message.';

//if the errors array is empty, send the mail
if (!$errors) {

	//recipient - replace your email here
	$to = 'curlykicksss@gmail.com';
	//sender - the visitor's name, sent from an address on this website's domain
	$from = str_replace(array("\r", "\n", '<', '>', '"'), '', $name) . ' <noreply@sgmsonlinesolutions.com>';

	//subject and the html message
	$subject = 'Enquiry: ' . str_replace(array("\r", "\n"), ' ', $service) . ' - ' . str_replace(array("\r", "\n"), ' ', $name);
	$message = 'Name: ' . htmlspecialchars($name) . '<br/><br/>
		       Phone: ' . htmlspecialchars($phone) . '<br/><br/>
		       Organisation: ' . ($organisation ? htmlspecialchars($organisation) : '-') . '<br/><br/>
		       Service: ' . htmlspecialchars($service) . '<br/><br/>
		       Message: ' . nl2br(htmlspecialchars($comment)) . '<br/>';

	//send the mail
	$result = sendmail($to, $subject, $message, $from);

	//if POST was used, display the message straight away
	if ($_POST) {
		if ($result) echo 'Thank you! We have received your message.';
		else echo 'Sorry, unexpected error. Please try again later';

	//else if GET was used, return the boolean value so that
	//ajax script can react accordingly
	//1 means success, 0 means failed
	} else {
		echo $result;
	}

//if the errors array has values
} else {
	//display the errors message
	for ($i=0; $i<count($errors); $i++) echo $errors[$i] . '<br/>';
	echo '<a href="contact.html">Back</a>';
	exit;
}


//Simple mail function with HTML header
function sendmail($to, $subject, $message, $from) {
	$headers = "MIME-Version: 1.0" . "\r\n";
	$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	$headers .= 'From: ' . $from . "\r\n";

	$result = mail($to,$subject,$message,$headers);

	if ($result) return 1;
	else return 0;
}

?>
